# Oxygen Custom Fonts

## Host google fonts locally

Use following website [website] to generate font files and font face.

[website]: https://google-webfonts-helper.herokuapp.com/
